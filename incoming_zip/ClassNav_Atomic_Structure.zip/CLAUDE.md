# ClassNav — Project Context for AI Coding Agents

> Status: **Stage 2 of the build (code written, not yet compiled or run).** This
> file describes only what exists in the repository today. Update it every time a
> stage is finished. Do not describe features that are not in the code.

## 1. Project overview
ClassNav is a Flutter mobile app for students of Divine Word College of Legazpi.
Students add their subjects, set weekly class schedules, and see the room for
each class. When a room is edited, the app keeps the previous room and shows a
"Room changed" notice so students are not confused about where to go.

- Course: CC105 final project, group **LAB'D**
- Platform: Android (release APK). iOS only if a Mac with Xcode and Apple signing is available.
- Language: Dart / Flutter, Material 3.

## 2. Architecture
Layered, one-way dependencies: `ui` -> `providers` -> `services` -> storage.
`models` and `core` are shared and depend on nothing else in the app.

| Layer | Folder | Responsibility |
|-------|--------|----------------|
| Core | `lib/core/` | Constants (route names), theme, pure helpers (validators) |
| Models | `lib/models/` | Plain Dart data classes with `toMap`/`fromMap`/`copyWith` |
| Services | `lib/services/` | SQLite (`DatabaseService`) and SharedPreferences (`PreferencesService`); no UI code |
| Providers | `lib/providers/` | State management (`ChangeNotifier`); call services, expose state to UI |
| Routing | `lib/routing/` | `onGenerateRoute` map from `AppRoutes` to pages |
| UI | `lib/ui/` | Atomic Design: atoms, molecules, organisms, templates, pages |

## 3. Folder structure (organized ZIP contents)
```
lib/
  main.dart
  app.dart
  core/
    constants/
      app_routes.dart
      subject_colors.dart
    utils/
      time_utils.dart
  providers/
    schedule_provider.dart
    theme_provider.dart
  routing/
    app_router.dart
  ui/
    atoms/
      app_button.dart
      app_text_field.dart
      color_dot.dart
    molecules/
      confirm_dialog.dart
      day_selector.dart
      empty_state.dart
      room_badge.dart
      subject_color_picker.dart
      subject_picker.dart
      time_field.dart
    organisms/
      class_card.dart
      session_form.dart
      subject_form.dart
      subject_tile.dart
    templates/
      page_template.dart
    pages/
      home_page.dart
      schedule_page.dart
      session_form_page.dart
      settings_page.dart
      subject_form_page.dart
      subjects_page.dart
test/
  time_utils_test.dart
```

**Important: this ZIP is an organized source-file bundle, not a complete runnable Flutter project.** It does not include `pubspec.yaml`, generated platform folders, or the following imported project files: `models/subject.dart`, `models/class_session.dart`, `services/database_service.dart`, `services/preferences_service.dart`, `core/theme/app_theme.dart`, and `core/utils/validators.dart`. Add or recover these files before expecting `flutter analyze`, `flutter test`, or `flutter run` to succeed.

Atomic Design rules for `lib/ui/`:
- **atoms**: smallest widgets (buttons, labels, color dot, text field wrapper). No provider access.
- **molecules**: small groups of atoms (e.g., room badge, day chip). No provider access.
- **organisms**: larger sections (e.g., class card, schedule list). May receive data via constructor only.
- **templates**: page layouts/scaffolds with slots. No data fetching.
- **pages**: full screens. Only pages and organisms-with-callbacks read providers.

## 4. Coding conventions
- Files `snake_case.dart`; classes `PascalCase`; private members start with `_`.
- One public widget/class per file where practical.
- Prefer `const` constructors. Keep widgets small; extract when a `build` exceeds ~80 lines.
- Use `Theme.of(context)` colors; never hard-code colors in pages.
- No business logic in widgets; put it in providers/services.
- Run `flutter analyze` and `flutter test` before every commit; fix warnings.
- Commit messages: imperative, specific (e.g., `Add room-change notice to ClassCard`).

## 5. State management
`provider` package with `ChangeNotifier`.
- `ScheduleProvider`: subjects, sessions, loading/error state, CRUD, duplicate-code and time-conflict checks. Save/delete methods return an error message (or null on success).
- `ThemeProvider`: `ThemeMode`, persisted via `PreferencesService`.
- Widgets read with `context.watch<T>()` (rebuild) or `context.read<T>()` (actions only).
- Providers never import `package:flutter/material.dart` widgets (only `ThemeMode`).

## 6. Navigation conventions
- Named routes only, declared in `AppRoutes` (`home`, `subjectForm`, `sessionForm`); resolved in `lib/routing/app_router.dart` via `onGenerateRoute`.
- Schedule, Subjects and Settings are tabs (`NavigationBar`) inside `HomePage`, not separate routes.
- Edit mode: pass the `Subject` / `ClassSession` as the route argument; no argument means add mode.
- Never use string literals for routes outside `AppRoutes`.

## 7. Data storage
- **SQLite (sqflite)**: tables `subjects` and `class_sessions` (foreign key with `ON DELETE CASCADE`). Times stored as minutes since midnight; `day_of_week` 1=Mon..7=Sun.
- **SharedPreferencesAsync**: only the theme mode.
- Room edits store `previous_room` and `room_changed_at` in `DatabaseService.updateSession`.
- Schedule conflicts are detected by `DatabaseService.hasConflict`.
- Schema changes require bumping the database `version` and adding `onUpgrade`.

## 8. Package guidelines
Add packages only with a clear purpose, via `flutter pub add`.
Current: `provider`, `sqflite`, `path`, `shared_preferences`, `intl`; dev: `flutter_lints`, `sqflite_common_ffi` (tests).
Do not add AI, blockchain, Firebase, or network packages unless the group agrees it solves the real problem.

## 9. Instructions for AI coding agents
1. Read this file first; follow the layer rules above.
2. Do not move or rename files without updating this file.
3. Do not claim features, tests, builds, or commits are done unless verified.
4. Keep changes small and explain where each file belongs.
5. Every change must pass `flutter analyze`; add or update tests for logic.
6. Never fabricate Git history or contributions; members commit with their own GitHub accounts.
7. Log any AI-caused bug honestly for the AI Usage Log (what happened, how it was caught, how it was fixed).

## 10. Security rules
- Never commit API keys, passwords, keystores (`*.jks`, `key.properties`), signing certificates, or provisioning profiles.
- Keep secrets out of source and out of this file.
- Validate all form input with `Validators` before saving; use parameterized SQL (`whereArgs`), never string-built queries.
- The app has no network access and collects no personal data beyond what the student types locally.
